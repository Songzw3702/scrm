package com.situ.scrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
